const cards = [
  {id:'policy-001',title:'상품등록 운영 기준 변경',severity:'HIGH',date:'시행 예정 · 샘플',tags:['상품등록'],base:'등록 상품 수와 판매 상태에 따라 점검이 필요할 수 있습니다.',why:'저성과·중복 상품이 많으면 신규 등록이나 노출 운영에 영향을 받을 수 있습니다.',actions:['최근 90일 판매가 없는 상품 목록을 추출합니다.','중복·유사 상품을 점검합니다.','정책 시행 전 전체 등록 상품 수를 기록합니다.'],confidence:92},
  {id:'policy-002',title:'광고 운영 기준 및 소재 검수 항목 변경',severity:'MEDIUM',date:'변경 감지 · 샘플',tags:['광고'],base:'광고를 운영하는 판매자는 소재와 표현을 다시 확인해야 할 수 있습니다.',why:'기존 소재가 새 검수 기준에 맞지 않으면 노출 중단이나 수정 요청이 발생할 수 있습니다.',actions:['현재 집행 중인 광고 소재를 목록화합니다.','효능·최상급·비교 표현이 포함된 소재를 우선 점검합니다.','중단 시 대체할 기본 소재를 준비합니다.'],confidence:86},
  {id:'policy-003',title:'배송 품질 평가 기준 변경',severity:'LOW',date:'이번 달 · 샘플',tags:['배송'],base:'배송 방식에 따라 확인 필요성이 달라집니다.',why:'출고 지연이나 배송 약속 불이행이 누적되면 노출과 판매자 평가에 영향을 줄 수 있습니다.',actions:['최근 출고 지연 주문 비율을 확인합니다.','주말·공휴일 출고 기준을 상품 페이지와 일치시킵니다.','물류 위탁사 SLA를 다시 확인합니다.'],confidence:79}
];

const grid = document.querySelector('#cardGrid');
const form = document.querySelector('#profileForm');
const title = document.querySelector('#cardsTitle');

document.querySelectorAll('.chip').forEach(btn => btn.addEventListener('click', () => btn.classList.toggle('active')));

function reasonFor(card, profile){
  if(card.tags.includes('상품등록') && ['500_1999','2000_plus'].includes(profile.productCount)) return '등록 상품 수가 많은 편이라 영향 가능성이 높습니다.';
  if(card.tags.includes('광고') && profile.usesAds) return '네이버 광고 사용 스토어이므로 변경 내용을 확인해야 합니다.';
  if(card.tags.includes('배송') && profile.usesNDelivery) return '도착보장·물류 서비스를 사용하므로 적용 가능성이 높습니다.';
  return '현재 입력 조건에서는 즉시 조치 필요성은 낮지만 원문 확인을 권장합니다.';
}

function render(profile=null){
  grid.innerHTML = cards.map(card => `
    <article class="policy-card ${card.severity.toLowerCase()}">
      <div class="policy-top"><span class="severity ${card.severity.toLowerCase()}">${card.severity}</span><small>${card.date}</small></div>
      <h3>${card.title}</h3>
      <p class="reason">${profile ? reasonFor(card, profile) : card.base}</p>
      <div class="impact"><b>왜 중요한가</b><p>${card.why}</p></div>
      <div><span class="small-title">권장 조치</span><ul>${card.actions.map(a=>`<li>${a}</li>`).join('')}</ul></div>
      <div class="policy-footer"><span>신뢰도 ${card.confidence}%</span><span>공식 원문 보기 ↗</span></div>
    </article>`).join('');
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const profile = {
    storeCount: document.querySelector('#storeCount').value,
    productCount: document.querySelector('#productCount').value,
    fulfillment: document.querySelector('#fulfillment').value,
    categories: [...document.querySelectorAll('.chip.active')].map(x=>x.dataset.value),
    usesAds: document.querySelector('#usesAds').checked,
    usesNDelivery: document.querySelector('#usesNDelivery').checked
  };
  title.textContent = '내 조건에 맞춘 샘플 판정';
  render(profile);
  document.querySelector('#cards').scrollIntoView({behavior:'smooth'});
});

render();
