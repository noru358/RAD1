# SellerGuard Static MVP

빌드 과정이 없는 순수 HTML/CSS/JavaScript 버전입니다.

## 배포

GitHub 저장소 루트에 아래 파일이 직접 보이도록 업로드하세요.

- index.html
- styles.css
- app.js
- vercel.json
- README.md

Vercel에서는 Framework Preset을 `Other`로 두면 됩니다. package.json과 npm 설치가 없으므로 이전 JSON/빌드 오류가 발생하지 않습니다.
